CHROMA_DB_PATH = "../../chroma_db"
CHROMA_DB_LISTINGS = "real_estate_listings"
LISTINGS_DATASET = "chicago_listings_1000.json"